#ifndef impala_version_h__
#define impala_version_h__

extern const char *mclDateTag;
extern const char *mclNumTag;
extern const char *mclYear;

#endif
