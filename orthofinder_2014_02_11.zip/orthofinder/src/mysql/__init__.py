import sys
from src import config

sys.path = [config.src_dir] + sys.path