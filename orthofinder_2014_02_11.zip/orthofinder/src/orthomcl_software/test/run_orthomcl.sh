../bin/orthomclInstallSchema orthomcl.config
